-- 检查 description 列是否已存在
IF NOT EXISTS (
    SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'charging_stations' 
    AND COLUMN_NAME = 'description'
)
BEGIN
    -- 添加 description 列
    ALTER TABLE charging_stations
    ADD description NVARCHAR(500) NULL;
    
    PRINT 'description 列已成功添加到 charging_stations 表';
END
ELSE
BEGIN
    PRINT 'description 列已存在于 charging_stations 表中';
END
