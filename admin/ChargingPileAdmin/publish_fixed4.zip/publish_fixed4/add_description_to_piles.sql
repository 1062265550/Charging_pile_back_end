-- 检查 description 列是否已存在于充电桩表中
IF NOT EXISTS (
    SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'charging_piles' 
    AND COLUMN_NAME = 'description'
)
BEGIN
    -- 添加 description 列到充电桩表
    ALTER TABLE charging_piles
    ADD description NVARCHAR(500) NULL;
    
    PRINT 'description 列已成功添加到 charging_piles 表';
END
ELSE
BEGIN
    PRINT 'description 列已存在于 charging_piles 表中';
END 